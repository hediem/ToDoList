import Tododata from './components/tododata';
import './App.css';

function App() {
  return (
    <Tododata/>
  );
}

export default App;
